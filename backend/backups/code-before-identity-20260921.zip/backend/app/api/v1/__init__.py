"""Versioned endpoint compatibility package."""

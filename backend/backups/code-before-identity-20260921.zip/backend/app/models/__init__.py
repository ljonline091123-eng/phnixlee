from app.models.market_data import (
    DataFetchLog,
    DataInterface,
    DataSource,
    DataSyncLog,
    StockFinancialReport,
    StockKline,
    StockNotice,
    StockNews,
    StockRealtimeQuote,
    StockSymbol,
    WatchlistItem,
)
from app.models.ai_hub import (
    AgentChildLink,
    AgentDataAssetLink,
    AgentDataSourceLink,
    AgentDefinition,
    AgentKnowledgeBaseLink,
    AgentSkillLink,
    AgentDataAsset,
    KnowledgeBase,
    KnowledgeGraph,
    GovernanceRun,
    KnowledgeDocument,
    KnowledgeEntity,
    KnowledgeRelation,
    ResearchReportRecord,
    PredictionLedger,
    SkillOptimizationDraft,
    ModelCallLog,
    ModelInstance,
    ModelProvider,
    ModelRouteRule,
    ModelSkill,
    ModelSkillRevision,
)
from app.models.schema_catalog import DatabaseTableComment
from app.models.context_event import StockContextEvent
from app.models.pipeline import PipelineRun, PipelineStageRun, ScheduledJob
from app.models.selection import SelectionCandidate, SelectionRun, SelectionSnapshot, SelectionTracking
from app.models.foundation import (
    FoundationEntity, FoundationSecurity, FoundationListing, FoundationEvidence,
    FoundationFact, FoundationFactEvidence, FoundationFactReview,
)
from app.db.base import Base
from app.models.company_graph import SecurityClassification, SourceIdentity
from app.models.taxonomy import ClassificationDefinition
from app.db.table_comments import apply_table_comments

apply_table_comments(Base.metadata)

__all__ = [
    "SecurityClassification", "SourceIdentity", "ClassificationDefinition",
    "FoundationEntity", "FoundationSecurity", "FoundationListing", "FoundationEvidence",
    "FoundationFact", "FoundationFactEvidence", "FoundationFactReview",
    "DataFetchLog",
    "DataInterface",
    "DataSource",
    "DataSyncLog",
    "StockFinancialReport",
    "StockKline",
    "StockNotice",
    "StockNews",
    "StockRealtimeQuote",
    "StockSymbol",
    "WatchlistItem",
    "ResearchReportRecord",
    "PredictionLedger",
    "SkillOptimizationDraft",
    "ModelCallLog",
    "ModelInstance",
    "ModelProvider",
    "ModelRouteRule",
    "ModelSkill",
    "ModelSkillRevision",
    "AgentDefinition",
    "AgentChildLink",
    "AgentSkillLink",
    "AgentDataAssetLink",
    "AgentDataSourceLink",
    "AgentKnowledgeBaseLink",
    "AgentDataAsset",
    "KnowledgeBase",
    "KnowledgeGraph",
    "GovernanceRun",
    "KnowledgeDocument",
    "KnowledgeEntity",
    "KnowledgeRelation",
    "DatabaseTableComment",
    "PipelineRun",
    "PipelineStageRun",
    "ScheduledJob",
    "SelectionRun",
    "SelectionCandidate",
    "SelectionTracking",
    "SelectionSnapshot",
]
